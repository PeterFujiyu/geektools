#\!/bin/bash
echo "Hello from test plugin\!"
